<?php
/**
 * Empty Cart Page 
 */

// Exit if accessed directly
if( ! defined( 'ABSPATH' ) ) exit();

?>
<div class="woocommerce woolentor-elementor-empty-cart">
    <?php
        do_action( 'stiles_cart_empty_content_build' );
    ?>
</div>