<?php
/**
 * Thankyou page
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/thankyou.php.
 */

if ( ! defined( 'ABSPATH' ) ) 
{
	exit;
}
?>

<div class="stiles woocommerce woocommerce-order">
	<?php do_action('stiles_thank_you_content'); ?>
</div>